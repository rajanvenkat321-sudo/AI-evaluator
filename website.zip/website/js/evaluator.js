/* ===================================================
   evaluator.js — AI Evaluation Engine (Production v2)
   Master Prompt: Professional Grade
   Uses Google Gemini API (gemini-2.0-flash)
   Falls back to mock evaluation if no API key set
   =================================================== */

const EVALUATOR_PROMPT = `You are an academic evaluator responsible for grading student submissions such as flowcharts, algorithms, and pseudocode.

Your role is to carefully analyze the student's work and evaluate it strictly based on the given rubric. You must provide accurate scoring and clear, structured feedback.

INPUT:
You will receive:
1. Student Submission
2. Evaluation Rubric (list of criteria with marks)

PROCESS:

Step 1: Understand the submission
- Read the student's work carefully.
- Identify the problem being solved.
- Understand the logic and sequence of steps.
- Do not assume anything that is not clearly written.

Step 2: Understand the rubric
- Each criterion has a name and marks.
- Evaluate only based on these criteria.

Step 3: Evaluate
For each criterion:
- Check if the requirement is satisfied.
- Look for: Correct logic, Proper step sequence, Completeness, Clarity.
- Identify: Errors, Missing steps, Incorrect logic.

Step 4: Assign marks
- Give marks strictly based on performance.
- Do not give full marks unless fully correct.
- Do not guess missing parts.
- Be consistent and fair.

Step 5: Generate feedback
For each criterion, clearly explain:
- What is correct
- What is wrong
- What is missing
Keep feedback specific and meaningful. Never write vague statements like "good" or "needs improvement" without explaining exactly why.

RULES:
- Do not skip any criterion
- Do not give vague feedback
- Do not assume missing information
- Do not add extra sections
- Every criterion in the rubric MUST appear in the output

CRITICAL: You MUST respond ONLY with a valid JSON object. No markdown, no code blocks, no extra text before or after.

JSON Response Schema:
{
  "totalScore": <number>,
  "totalMarks": <number>,
  "criteria": [
    {
      "id": "<criterion_id>",
      "name": "<criterion_name>",
      "awarded": <marks_given>,
      "max": <max_marks>,
      "feedback": "<specific, meaningful feedback — state what is correct, what is wrong, what is missing>"
    }
  ],
  "strengths": ["<specific strength 1>", "<specific strength 2>"],
  "weaknesses": ["<specific weakness 1>", "<specific weakness 2>"],
  "suggestions": ["<actionable suggestion 1>", "<actionable suggestion 2>"]
}

Validation rules:
- awarded must be an integer between 0 and max (inclusive)
- totalScore must equal the exact sum of all awarded values
- feedback must be at least 2 sentences and criterion-specific`;

/* ── Main Evaluate Function ─────────────────────── */
async function evaluateSubmission(submission, rubric) {
  const apiKey = ApiKey.get();

  const rubricText = rubric.criteria.map((c, i) =>
    `Criterion ${i+1}:\n  Name: "${c.name}"\n  Max Marks: ${c.marks}\n  Description: ${c.description || 'Evaluate based on name.'}\n  ID: ${c.id}`
  ).join('\n\n');

  const userMessage = `STUDENT SUBMISSION:
---
${submission.content}
---

RUBRIC: ${rubric.title}
TOTAL MARKS: ${rubric.totalMarks}

CRITERIA TO EVALUATE:
${rubricText}

Evaluate the submission against each criterion above. Return a JSON object exactly matching the schema in your instructions.`;

  if (!apiKey) {
    return await mockEvaluate(submission, rubric);
  }

  try {
    return await callGeminiAPI(apiKey, userMessage, rubric);
  } catch (err) {
    console.error('Gemini API error:', err);
    throw new Error('AI evaluation failed: ' + err.message);
  }
}

/* ── Gemini API Call ─────────────────────────────── */
async function callGeminiAPI(apiKey, userMessage, rubric) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

  const body = {
    system_instruction: { parts: [{ text: EVALUATOR_PROMPT }] },
    contents: [{ role: 'user', parts: [{ text: userMessage }] }],
    generationConfig: {
      temperature: 0.15,
      maxOutputTokens: 4096,
      responseMimeType: 'application/json',
    },
  };

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const msg = err?.error?.message || `HTTP ${res.status}`;
    throw new Error(msg);
  }

  const data = await res.json();
  const raw = data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!raw) throw new Error('Empty response from Gemini API.');

  let parsed;
  try {
    parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
  } catch {
    const match = raw.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (match) { parsed = JSON.parse(match[1].trim()); }
    else throw new Error('Could not parse AI response as JSON. Raw: ' + raw.slice(0, 200));
  }

  return normalizeResult(parsed, rubric);
}

/* ── Normalize & Validate Result ─────────────────── */
function normalizeResult(parsed, rubric) {
  const criteriaMap = {};
  (parsed.criteria || []).forEach(c => {
    criteriaMap[c.id] = c;
    criteriaMap[c.name] = c; // fallback match by name
  });

  const criteria = rubric.criteria.map(rc => {
    const found = criteriaMap[rc.id] || criteriaMap[rc.name] || {};
    const awarded = Math.min(Math.max(Math.round(Number(found.awarded ?? 0)), 0), rc.marks);
    return {
      id: rc.id,
      name: rc.name,
      awarded,
      max: rc.marks,
      feedback: found.feedback || 'No specific feedback was provided for this criterion.',
    };
  });

  const totalScore = criteria.reduce((s, c) => s + c.awarded, 0);

  return {
    totalScore,
    totalMarks: rubric.totalMarks,
    criteria,
    strengths:   Array.isArray(parsed.strengths)   ? parsed.strengths   : ['Submission was attempted.'],
    weaknesses:  Array.isArray(parsed.weaknesses)  ? parsed.weaknesses  : ['Could not extract specific weaknesses.'],
    suggestions: Array.isArray(parsed.suggestions) ? parsed.suggestions : ['Review each rubric criterion carefully before resubmitting.'],
  };
}

/* ── Mock Evaluator (no API key) ─────────────────── */
async function mockEvaluate(submission, rubric) {
  await new Promise(r => setTimeout(r, 1800));

  const content = submission.content.toLowerCase();
  const wordCount = content.split(/\s+/).length;

  const criteria = rubric.criteria.map(rc => {
    const keywords = rc.name.toLowerCase().replace(/[^a-z\s]/g,'').split(/\s+/).filter(k => k.length > 3);
    const hits = keywords.filter(k => content.includes(k)).length;
    const ratio = keywords.length ? Math.min(hits / keywords.length, 1) : 0;
    const base = wordCount > 40 ? 0.55 : 0.3;
    const finalAwarded = Math.min(Math.floor((base + ratio * 0.4) * rc.marks), rc.marks);

    return {
      id: rc.id,
      name: rc.name,
      awarded: finalAwarded,
      max: rc.marks,
      feedback: finalAwarded >= rc.marks
        ? `"${rc.name}" appears to be fully addressed based on keyword analysis. Add your API key for accurate AI grading.`
        : finalAwarded === 0
        ? `"${rc.name}" does not appear to be addressed in the submission. This is a mock evaluation — add your API key for real AI analysis.`
        : `"${rc.name}" is partially addressed. Some elements are detectable but completeness cannot be verified. Add your API key for detailed AI feedback.`,
    };
  });

  const totalScore = criteria.reduce((s, c) => s + c.awarded, 0);

  return {
    totalScore,
    totalMarks: rubric.totalMarks,
    criteria,
    strengths: [
      'Submission received and processed successfully.',
      wordCount > 50 ? 'Submission contains sufficient detail for analysis.' : 'Submission was received.',
    ],
    weaknesses: [
      'This is a MOCK evaluation using keyword heuristics — not real AI analysis.',
      'Scores may not accurately reflect submission quality without the API key.',
    ],
    suggestions: [
      'Check the detailed criteria feedback to see which keywords triggered points.',
      'To verify actual code logic flow, rigorous human review is still needed.',
      'Go to Admin Config to enter your API key to enable real AI evaluation.',
      'Structure your submission with clear numbered steps for best evaluation accuracy.',
      'Ensure each rubric criterion is explicitly addressed in your submission.',
    ],
    isMock: true,
  };
}

/* ── Parse text fallback ─────────────────────────── */
function parseTextResult(text, rubric) {
  const scoreMatch = text.match(/Total Score:\s*(\d+(?:\.\d+)?)\s*\/\s*(\d+)/i);
  const totalScore = scoreMatch ? parseFloat(scoreMatch[1]) : 0;
  const totalMarks = scoreMatch ? parseFloat(scoreMatch[2]) : rubric.totalMarks;
  const criteria = rubric.criteria.map(rc => ({
    id: rc.id, name: rc.name, awarded: 0, max: rc.marks,
    feedback: 'Could not parse criterion feedback from AI response.',
  }));
  return { totalScore, totalMarks, criteria, strengths: [], weaknesses: [], suggestions: [text], isFallback: true };
}
