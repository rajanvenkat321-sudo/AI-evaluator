/* ===================================================
   storage.js — LocalStorage Data Layer
   =================================================== */

const DB = {
  USERS:       'rub_users',
  RUBRICS:     'rub_rubrics',
  SUBMISSIONS: 'rub_submissions',
  RESULTS:     'rub_results',
  ASSIGNMENTS: 'rub_assignments',
  API_KEY:     'rub_api_key',
};

/* ── Helpers ──────────────────────────────────────── */
function _get(key) {
  try { return JSON.parse(localStorage.getItem(key)) || []; }
  catch { return []; }
}
function _set(key, val) {
  localStorage.setItem(key, JSON.stringify(val));
}
function _getObj(key) {
  try { return JSON.parse(localStorage.getItem(key)) || {}; }
  catch { return {}; }
}
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
function now() { return new Date().toISOString(); }

/* ── Seed Demo Data ────────────────────────────────── */
function seedDemoData() {
  if (localStorage.getItem('rub_seeded')) return;

  // Demo users
  const users = [
    { id: 'u1', name: 'Admin User',    email: 'admin@eval.ai',    password: 'admin123',    role: 'admin',   createdAt: now() },
    { id: 'u2', name: 'Dr. Priya Sharma', email: 'teacher@eval.ai', password: 'teacher123', role: 'teacher', createdAt: now() },
    { id: 'u3', name: 'Prof. Rajan Kumar', email: 'teacher2@eval.ai', password: 'teacher123', role: 'teacher', createdAt: now() },
    { id: 'u4', name: 'Arjun Mehta',   email: 'student@eval.ai',  password: 'student123',  role: 'student', createdAt: now() },
    { id: 'u5', name: 'Kavya Nair',    email: 'student2@eval.ai', password: 'student123',  role: 'student', createdAt: now() },
    { id: 'u6', name: 'Rahul Patel',   email: 'student3@eval.ai', password: 'student123',  role: 'student', createdAt: now() },
  ];
  _set(DB.USERS, users);

  // Demo rubrics
  const rubrics = [
    {
      id: 'r1',
      title: 'Sorting Algorithm Flowchart',
      description: 'Evaluate student-drawn bubble sort / selection sort flowchart using text steps.',
      teacherId: 'u2',
      totalMarks: 20,
      createdAt: now(),
      criteria: [
        { id: 'c1', name: 'Start and End Nodes',         marks: 3,  description: 'Both START and END nodes clearly present.' },
        { id: 'c2', name: 'Input / Output Steps',        marks: 3,  description: 'Input of array and output of sorted array included.' },
        { id: 'c3', name: 'Comparison Logic',            marks: 5,  description: 'Correct conditional (decision) step for element comparison.' },
        { id: 'c4', name: 'Swap / Assignment Step',      marks: 4,  description: 'Correct swap mechanism shown.' },
        { id: 'c5', name: 'Loop / Iteration Structure',  marks: 3,  description: 'Proper loop back arrow or iteration shown.' },
        { id: 'c6', name: 'Clarity and Sequence',        marks: 2,  description: 'Steps are in logical order and clearly labeled.' },
      ],
    },
    {
      id: 'r2',
      title: 'Binary Search Algorithm',
      description: 'Evaluate pseudocode / algorithm for binary search on a sorted array.',
      teacherId: 'u2',
      totalMarks: 15,
      createdAt: now(),
      criteria: [
        { id: 'c7',  name: 'Initialization (low/high)',  marks: 3, description: 'Correct initialization of low and high pointers.' },
        { id: 'c8',  name: 'Midpoint Calculation',       marks: 3, description: 'Correct mid = (low+high)/2 formula or equivalent.' },
        { id: 'c9',  name: 'Comparison and Branching',   marks: 4, description: 'Correct three-way comparison: found, go left, go right.' },
        { id: 'c10', name: 'Loop Termination',           marks: 3, description: 'Correct condition to stop the loop (low > high or found).' },
        { id: 'c11', name: 'Return / Output',            marks: 2, description: 'Returns index or -1 appropriately.' },
      ],
    },
    {
      id: 'r3',
      title: 'Stack Operations Pseudocode',
      description: 'Evaluate pseudocode for push, pop, and peek operations on a stack.',
      teacherId: 'u3',
      totalMarks: 12,
      createdAt: now(),
      criteria: [
        { id: 'c12', name: 'Push Operation',    marks: 4, description: 'Correct push with overflow check.' },
        { id: 'c13', name: 'Pop Operation',     marks: 4, description: 'Correct pop with underflow check.' },
        { id: 'c14', name: 'Peek / Top',        marks: 2, description: 'Correct peek without removing element.' },
        { id: 'c15', name: 'Code Clarity',      marks: 2, description: 'Readable and well-commented pseudocode.' },
      ],
    },
  ];
  _set(DB.RUBRICS, rubrics);

  // Demo assignments
  const assignments = [
    { id: 'a1', rubricId: 'r1', title: 'Lab 1: Sorting Flowchart',   dueDate: '2026-04-20', teacherId: 'u2', assignedTo: ['u4','u5','u6'], createdAt: now() },
    { id: 'a2', rubricId: 'r2', title: 'Lab 2: Binary Search',       dueDate: '2026-04-27', teacherId: 'u2', assignedTo: ['u4','u5'],      createdAt: now() },
    { id: 'a3', rubricId: 'r3', title: 'Lab 3: Stack Pseudocode',    dueDate: '2026-05-05', teacherId: 'u3', assignedTo: ['u4','u5','u6'], createdAt: now() },
  ];
  _set(DB.ASSIGNMENTS, assignments);

  // Demo submission + result (Arjun)
  const submissions = [
    {
      id: 's1',
      studentId: 'u4',
      assignmentId: 'a1',
      rubricId: 'r1',
      content: `START
INPUT: Array A with n elements
Set i = 0 (outer loop counter)
WHILE i < n-1 DO:
  Set j = 0 (inner loop counter)
  WHILE j < n-i-1 DO:
    IF A[j] > A[j+1] THEN:
      SWAP A[j] and A[j+1]
    END IF
    j = j + 1
  END WHILE
  i = i + 1
END WHILE
OUTPUT: Sorted Array A
END`,
      submittedAt: now(),
      status: 'evaluated',
    },
  ];
  _set(DB.SUBMISSIONS, submissions);

  const results = [
    {
      id: 'res1',
      submissionId: 's1',
      studentId: 'u4',
      rubricId: 'r1',
      assignmentId: 'a1',
      totalScore: 17,
      totalMarks: 20,
      evaluatedAt: now(),
      criteria: [
        { id: 'c1', name: 'Start and End Nodes',        awarded: 3, max: 3, feedback: 'Both START and END nodes are clearly present and correctly placed at the beginning and end of the flowchart.' },
        { id: 'c2', name: 'Input / Output Steps',       awarded: 3, max: 3, feedback: 'Input of array A with n elements is declared. Output of sorted array is shown correctly.' },
        { id: 'c3', name: 'Comparison Logic',           awarded: 4, max: 5, feedback: 'Comparison A[j] > A[j+1] is correct and forms a valid decision step. However, the decision diamond is not explicitly labeled as a flowchart shape.' },
        { id: 'c4', name: 'Swap / Assignment Step',     awarded: 4, max: 4, feedback: 'Swap of A[j] and A[j+1] is correctly shown.' },
        { id: 'c5', name: 'Loop / Iteration Structure', awarded: 2, max: 3, feedback: 'Both outer and inner loops are present with correct counters. The loop-back arrow is implied but not explicitly diagrammed with a return arrow label.' },
        { id: 'c6', name: 'Clarity and Sequence',       awarded: 1, max: 2, feedback: 'Steps are in correct logical order but some labels could be clearer (e.g., the SWAP step should be labeled as a process box).' },
      ],
      strengths: [
        'Correct bubble sort logic with nested loops.',
        'Proper start/end and input/output steps.',
        'Swap logic is accurate.',
      ],
      weaknesses: [
        'Decision diamond not explicitly labeled as a flowchart shape.',
        'Loop-back arrows not explicitly drawn.',
        'Some labels lack clarity.',
      ],
      suggestions: [
        'Clearly label each box type (Start/End = oval, Process = rectangle, Decision = diamond).',
        'Draw explicit loop-back arrows to show iteration flow.',
        'Add comments to explain what each step does.',
      ],
    },
  ];
  _set(DB.RESULTS, results);

  localStorage.setItem('rub_seeded', '1');
}

/* ── User CRUD ─────────────────────────────────────── */
const Users = {
  all: ()       => _get(DB.USERS),
  get: (id)     => _get(DB.USERS).find(u => u.id === id),
  findByEmail:  (email) => _get(DB.USERS).find(u => u.email.toLowerCase() === email.toLowerCase()),
  add: (user)   => { const all = _get(DB.USERS); all.push({ ...user, id: uid(), createdAt: now() }); _set(DB.USERS, all); return user; },
  update: (id, data) => {
    const all = _get(DB.USERS).map(u => u.id === id ? { ...u, ...data } : u);
    _set(DB.USERS, all);
  },
  delete: (id)  => _set(DB.USERS, _get(DB.USERS).filter(u => u.id !== id)),
  count: ()     => _get(DB.USERS).length,
  byRole: (role)=> _get(DB.USERS).filter(u => u.role === role),
};

/* ── Rubric CRUD ───────────────────────────────────── */
const Rubrics = {
  all: ()       => _get(DB.RUBRICS),
  get: (id)     => _get(DB.RUBRICS).find(r => r.id === id),
  byTeacher: (tid) => _get(DB.RUBRICS).filter(r => r.teacherId === tid),
  add: (rub)    => { const all = _get(DB.RUBRICS); const newR = { ...rub, id: uid(), createdAt: now() }; all.push(newR); _set(DB.RUBRICS, all); return newR; },
  update: (id, data) => {
    const all = _get(DB.RUBRICS).map(r => r.id === id ? { ...r, ...data } : r);
    _set(DB.RUBRICS, all);
  },
  delete: (id)  => _set(DB.RUBRICS, _get(DB.RUBRICS).filter(r => r.id !== id)),
  count: ()     => _get(DB.RUBRICS).length,
};

/* ── Assignment CRUD ───────────────────────────────── */
const Assignments = {
  all: ()       => _get(DB.ASSIGNMENTS),
  get: (id)     => _get(DB.ASSIGNMENTS).find(a => a.id === id),
  byTeacher: (tid)  => _get(DB.ASSIGNMENTS).filter(a => a.teacherId === tid),
  byStudent: (sid)  => _get(DB.ASSIGNMENTS).filter(a => a.assignedTo && a.assignedTo.includes(sid)),
  add: (asgn)   => { const all = _get(DB.ASSIGNMENTS); const newA = { ...asgn, id: uid(), createdAt: now() }; all.push(newA); _set(DB.ASSIGNMENTS, all); return newA; },
  update: (id, data) => {
    const all = _get(DB.ASSIGNMENTS).map(a => a.id === id ? { ...a, ...data } : a);
    _set(DB.ASSIGNMENTS, all);
  },
  delete: (id)  => _set(DB.ASSIGNMENTS, _get(DB.ASSIGNMENTS).filter(a => a.id !== id)),
};

/* ── Submission CRUD ───────────────────────────────── */
const Submissions = {
  all: ()       => _get(DB.SUBMISSIONS),
  get: (id)     => _get(DB.SUBMISSIONS).find(s => s.id === id),
  byStudent: (sid) => _get(DB.SUBMISSIONS).filter(s => s.studentId === sid),
  byAssignment: (aid) => _get(DB.SUBMISSIONS).filter(s => s.assignmentId === aid),
  byStudentAndAssignment: (sid, aid) => _get(DB.SUBMISSIONS).find(s => s.studentId === sid && s.assignmentId === aid),
  add: (sub)    => { const all = _get(DB.SUBMISSIONS); const newS = { ...sub, id: uid(), submittedAt: now(), status: 'pending' }; all.push(newS); _set(DB.SUBMISSIONS, all); return newS; },
  update: (id, data) => {
    const all = _get(DB.SUBMISSIONS).map(s => s.id === id ? { ...s, ...data } : s);
    _set(DB.SUBMISSIONS, all);
  },
  count: ()     => _get(DB.SUBMISSIONS).length,
};

/* ── Results CRUD ──────────────────────────────────── */
const Results = {
  all: ()       => _get(DB.RESULTS),
  get: (id)     => _get(DB.RESULTS).find(r => r.id === id),
  bySubmission: (sid) => _get(DB.RESULTS).find(r => r.submissionId === sid),
  byStudent: (sid)    => _get(DB.RESULTS).filter(r => r.studentId === sid),
  add: (res)    => { const all = _get(DB.RESULTS); const newR = { ...res, id: uid(), evaluatedAt: now() }; all.push(newR); _set(DB.RESULTS, all); return newR; },
  count: ()     => _get(DB.RESULTS).length,
};

/* ── API Key ───────────────────────────────────────── */
const ApiKey = {
  get: ()      => localStorage.getItem(DB.API_KEY) || '',
  set: (key)   => localStorage.setItem(DB.API_KEY, key),
  clear: ()    => localStorage.removeItem(DB.API_KEY),
};

/* ── Date Helpers ──────────────────────────────────── */
function formatDate(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}
function formatDateTime(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}
function scoreColor(pct) {
  if (pct >= 80) return 'var(--accent-success)';
  if (pct >= 60) return 'var(--accent-warn)';
  return 'var(--accent-danger)';
}
function scoreBadge(pct) {
  if (pct >= 80) return 'badge-green';
  if (pct >= 60) return 'badge-yellow';
  return 'badge-red';
}
function gradeLabel(pct) {
  if (pct >= 90) return 'A+';
  if (pct >= 80) return 'A';
  if (pct >= 70) return 'B';
  if (pct >= 60) return 'C';
  if (pct >= 50) return 'D';
  return 'F';
}

// Init
seedDemoData();
